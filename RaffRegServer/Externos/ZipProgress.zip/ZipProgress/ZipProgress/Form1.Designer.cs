﻿namespace ZipProgress
{
    partial class ZipProgress
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonCompress = new System.Windows.Forms.Button();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.labelCompressionStatus = new System.Windows.Forms.Label();
            this.progressBar2 = new System.Windows.Forms.ProgressBar();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.labelFilename = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buttonCompress
            // 
            this.buttonCompress.Location = new System.Drawing.Point(12, 12);
            this.buttonCompress.Name = "buttonCompress";
            this.buttonCompress.Size = new System.Drawing.Size(269, 38);
            this.buttonCompress.TabIndex = 0;
            this.buttonCompress.Text = "Compress !";
            this.buttonCompress.UseVisualStyleBackColor = true;
            this.buttonCompress.Click += new System.EventHandler(this.buttonCompress_Click);
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(12, 140);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(656, 34);
            this.progressBar1.TabIndex = 1;
            // 
            // labelCompressionStatus
            // 
            this.labelCompressionStatus.AutoSize = true;
            this.labelCompressionStatus.Location = new System.Drawing.Point(12, 79);
            this.labelCompressionStatus.Name = "labelCompressionStatus";
            this.labelCompressionStatus.Size = new System.Drawing.Size(119, 13);
            this.labelCompressionStatus.TabIndex = 2;
            this.labelCompressionStatus.Text = "labelCompressionStatus";
            // 
            // progressBar2
            // 
            this.progressBar2.Location = new System.Drawing.Point(12, 100);
            this.progressBar2.Name = "progressBar2";
            this.progressBar2.Size = new System.Drawing.Size(656, 34);
            this.progressBar2.TabIndex = 3;
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.DefaultExt = "zip";
            this.saveFileDialog1.SupportMultiDottedExtensions = true;
            // 
            // labelFilename
            // 
            this.labelFilename.AutoSize = true;
            this.labelFilename.Location = new System.Drawing.Point(12, 61);
            this.labelFilename.Name = "labelFilename";
            this.labelFilename.Size = new System.Drawing.Size(71, 13);
            this.labelFilename.TabIndex = 4;
            this.labelFilename.Text = "labelFilename";
            // 
            // ZipProgress
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(680, 181);
            this.Controls.Add(this.labelFilename);
            this.Controls.Add(this.progressBar2);
            this.Controls.Add(this.labelCompressionStatus);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.buttonCompress);
            this.Name = "ZipProgress";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ZipProgress";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonCompress;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Label labelCompressionStatus;
        private System.Windows.Forms.ProgressBar progressBar2;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.Label labelFilename;
    }
}

